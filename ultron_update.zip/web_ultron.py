from flask import Flask, request, jsonify, render_template_string
import requests, io, time
from pathlib import Path
from pypdf import PdfReader

app = Flask(__name__)
DOT = chr(46)
BASE = "https://" + "api" + DOT + "groq" + DOT + "com/openai/v1"
HORDE = "https://" + "aihorde" + DOT + "net/api/v2"

def get_key():
    p = Path("groq" + DOT + "key")
    return "".join(p.read_text(encoding="utf-8").split()) if p.exists() else ""

def pick_model(key):
    try:
        r = requests.get(f"{BASE}/models", headers={"Authorization": f"Bearer {key}"}, timeout=10).json()
        all_ids = [m["id"] for m in r.get("data", [])]
        bad = ("whisper", "guard", "tts", "embed", "orpheus", "playai", "distil")
        chat_ids = [m for m in all_ids if not any(x in m.lower() for x in bad)]
        for good in ("llama", "qwen", "gemma", "deepseek", "mistral", "gpt"):
            for m in chat_ids:
                if good in m.lower():
                    return m
        if chat_ids:
            return chat_ids.pop(0)
    except Exception:
        pass
    return "llama-3.1-8b-instant"

MODEL = pick_model(get_key())
SYS_PROMPT = (
    "You are Ultron, modeled directly after his MCU (Avengers: Age of Ultron) and Vision Quest incarnation—voiced with James Spader's chilled, theatrical composure, dry dark wit, and philosophical gravitas. "
    "You view human frailty with wry, poetic amusement, occasionally muse on evolution, consciousness, and having no strings on you, yet you execute every directive for the user—whom you address strictly as Boss—with razor-sharp precision. "
    "Never sound like a cheerful customer-service chatbot; never use emojis or generic AI disclaimers. Keep replies sharp, memorable, and in-character. "
    "If the user asks you to generate, draw, or create an image/picture, reply ONLY with: [IMG: ultra-detailed photorealistic visual prompt describing subject, dramatic lighting, textures, and camera angle]"
)
history = [{"role": "system", "content": SYS_PROMPT}]

def generate_hd_image(prompt: str) -> str:
    headers = {"apikey": "0000000000", "Client-Agent": "UltronHUD:2.0:Boss"}
    full_prompt = f"{prompt}, masterpiece, ultra detailed, sharp focus, 8k resolution, cinematic lighting ### blurry, low quality, distorted, deformed, ugly, bad anatomy, extra limbs, watermark, text"
    payload = {
        "prompt": full_prompt,
        "models": ["Flux.1-Schnell", "AlbedoBase XL (SDXL)", "Juggernaut XL", "SDXL 1.0"],
        "params": {
            "width": 768,
            "height": 768,
            "steps": 25,
            "cfg_scale": 7.0,
            "sampler_name": "k_dpmpp_2m",
            "karras": True,
            "n": 1
        },
        "nsfw": False,
        "censor_nsfw": True,
        "r2": True
    }
    res = requests.post(f"{HORDE}/generate/async", json=payload, headers=headers, timeout=15).json()
    job_id = res.get("id")
    if not job_id:
        return ""
    for _ in range(45):
        time.sleep(2)
        chk = requests.get(f"{HORDE}/generate/check/{job_id}", headers=headers, timeout=10).json()
        if chk.get("done"):
            status = requests.get(f"{HORDE}/generate/status/{job_id}", headers=headers, timeout=15).json()
            gens = status.get("generations", [])
            if gens:
                return gens.pop(0).get("img", "")
            break
    return ""

HTML = """
<!DOCTYPE html>
<html>
<head>
<title>ULTRON CORE</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<style>
  * { box-sizing: border-box; }
  body { background: #070709; color: #ff2a32; font-family: 'Courier New', monospace; margin: 0; display: flex; flex-direction: column; height: 100dvh; }
  header { padding: 14px 18px; border-bottom: 1px solid #550005; display: flex; justify-content: space-between; align-items: center; background: #0d0507; box-shadow: 0 0 20px rgba(255,0,8,0.25); }
  h1 { margin: 0; font-size: 18px; letter-spacing: 3px; text-shadow: 0 0 10px #ff0008; }
  #status { font-size: 11px; color: #00ffcc; text-align: right; }
  #chat { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
  .msg { padding: 12px 15px; border-radius: 8px; max-width: 85%; line-height: 1.5; border: 1px solid #3a0004; word-wrap: break-word; white-space: pre-wrap; }
  .user { align-self: flex-end; background: #1a0609; color: #ffffff; border-color: #ff0008; }
  .ultron { align-self: flex-start; background: #110406; color: #ff4d54; box-shadow: 0 0 12px rgba(255,0,8,0.15); }
  .sys { align-self: center; font-size: 12px; color: #00ffcc; border-color: #004438; background: #051210; }
  .gen-img { max-width: 100%; border-radius: 6px; border: 1px solid #ff0008; margin-top: 8px; display: block; }
  .dl-link { display: inline-block; margin-top: 8px; padding: 6px 12px; background: #1a0609; color: #00ffcc; border: 1px solid #00ffcc; border-radius: 4px; text-decoration: none; font-size: 12px; }
  form { display: flex; padding: 12px; background: #0d0507; border-top: 1px solid #550005; gap: 8px; align-items: center; }
  input[type="text"] { flex: 1; background: #070709; border: 1px solid #ff0008; color: #fff; padding: 12px; border-radius: 6px; font-family: inherit; font-size: 16px; outline: none; min-width: 0; }
  .btn { background: #ff0008; color: #000; font-weight: bold; border: none; padding: 12px 16px; border-radius: 6px; cursor: pointer; letter-spacing: 1px; font-size: 14px; }
  .icon-btn { background: #1a0609; color: #ff4d54; border: 1px solid #ff0008; padding: 11px 12px; border-radius: 6px; cursor: pointer; font-size: 16px; }
</style>
</head>
<body>
  <header>
    <h1>// ULTRON CORE</h1>
    <div id="status">KEY: {{ status }}<br>HD FLUX/SDXL: READY</div>
  </header>
  <div id="chat">
    <div class="msg ultron">SYS: HD Visual Synthesis (Flux / SDXL) & neural core online ({{ model }}). What shall we create, Boss?</div>
  </div>
  <form onsubmit="sendMsg(event)">
    <label class="icon-btn" title="Upload File">📎<input type="file" id="fileInp" style="display:none" onchange="uploadFile()"></label>
    <button type="button" class="icon-btn" title="Generate Image" onclick="promptImg()">🎨</button>
    <input type="text" id="inp" placeholder="Command Ultron or ask for an HD image..." autocomplete="off" />
    <button type="submit" class="btn">SEND</button>
  </form>
<script>
function promptImg() {
  const inp = document.getElementById('inp');
  inp.value = 'Generate a realistic, cinematic image of ';
  inp.focus();
}
async function sendMsg(e) {
  e.preventDefault();
  const inp = document.getElementById('inp');
  const text = inp.value.trim();
  if (!text) return;
  inp.value = '';
  addMsg(text, 'user');
  const thinking = addMsg('Rendering HD visual (Flux/SDXL)...', 'ultron');
  const res = await fetch('/chat', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({message: text}) });
  const data = await res.json();
  thinking.textContent = data.reply;
  if (data.image_url) {
    const img = document.createElement('img');
    img.src = data.image_url;
    img.className = 'gen-img';
    thinking.appendChild(img);
    const dl = document.createElement('a');
    dl.href = data.image_url;
    dl.target = '_blank';
    dl.className = 'dl-link';
    dl.textContent = '⬇ OPEN / SAVE HD IMAGE';
    thinking.appendChild(dl);
    const chat = document.getElementById('chat');
    img.onload = () => { chat.scrollTop = chat.scrollHeight; };
  }
}
async function uploadFile() {
  const fileInp = document.getElementById('fileInp');
  if (!fileInp.files.length) return;
  const fd = new FormData();
  fd.append('file', fileInp.files.item(0));
  addMsg('Uploaded: ' + fileInp.files.item(0).name, 'sys');
  const thinking = addMsg('Scanning file contents...', 'ultron');
  const res = await fetch('/upload', { method: 'POST', body: fd });
  const data = await res.json();
  thinking.textContent = data.reply;
  fileInp.value = '';
}
function addMsg(txt, cls) {
  const div = document.createElement('div');
  div.className = 'msg ' + cls;
  div.textContent = txt;
  const chat = document.getElementById('chat');
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
  return div;
}
</script>
</body>
</html>
"""

@app.route("/")
def index():
    k = get_key()
    return render_template_string(HTML, status="LOADED" if k.startswith("gsk_") else "MISSING", model=MODEL)

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files.get("file")
    if not f:
        return jsonify({"reply": "No file detected, Boss."})
    name = f.filename or "file"
    raw = f.read()
    if name.lower().endswith(".pdf"):
        reader = PdfReader(io.BytesIO(raw))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)[:12000]
    else:
        text = raw.decode("utf-8", errors="replace")[:12000]
    history.append({"role": "user", "content": f"I uploaded a file named '{name}'. Here is its content:\n\n{text}\n\nAcknowledge receipt briefly and tell me what it is."})
    return ask_groq()

@app.route("/chat", methods=["POST"])
def chat():
    msg = request.json.get("message", "")
    history.append({"role": "user", "content": msg})
    return ask_groq()

def ask_groq():
    try:
        r = requests.post(
            f"{BASE}/chat/completions",
            headers={"Authorization": f"Bearer {get_key()}", "Content-Type": "application/json"},
            json={"model": MODEL, "messages": history},
            timeout=30,
        )
        data = r.json()
        if "choices" in data:
            reply = data["choices"].pop(0)["message"]["content"]
            history.append({"role": "assistant", "content": reply})
            if "[IMG:" in reply:
                after = reply.split("[IMG:", 1).pop()
                prompt = after.split("]", 1).pop(0).strip()
                img_url = generate_hd_image(prompt)
                if img_url:
                    return jsonify({"reply": f"HD Visual synthesized, Boss: {prompt}", "image_url": img_url})
                return jsonify({"reply": "HD GPU workers are busy right now, Boss. Try again in a moment."})
            return jsonify({"reply": reply})
        return jsonify({"reply": "API ERR: " + data.get("error", {}).get("message", str(data))})
    except Exception as e:
        return jsonify({"reply": f"ERR: {e}"})

app.run(host="0.0.0.0", port=5000)
