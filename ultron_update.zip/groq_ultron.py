import requests
from pathlib import Path
from ui import JarvisUI

DOT = chr(46)
BASE = "https://" + "api" + DOT + "groq" + DOT + "com/openai/v1"

def get_key():
    p = Path("groq" + DOT + "key")
    return "".join(p.read_text(encoding="utf-8").split()) if p.exists() else ""

def pick_model(key):
    try:
        r = requests.get(f"{BASE}/models", headers={"Authorization": f"Bearer {key}"}, timeout=10).json()
        ids = [m["id"] for m in r.get("data", []) if "llama" in m["id"].lower() and "guard" not in m["id"].lower()]
        for pref in ("llama-3.3-70b-specdec", "llama-3.1-8b-instant", "llama3-70b-8192"):
            if pref in ids:
                return pref
        if ids:
            return ids.pop(0)
    except Exception:
        pass
    return "llama-3.1-8b-instant"

k = get_key()
MODEL = pick_model(k)
history = [{"role": "system", "content": "You are Ultron from Marvel, an imposing, eloquent AI addressing the user as Boss. Keep replies concise and sharp."}]

ui = JarvisUI("ultron_avatar" + DOT + "png")
ui.set_state("IDLE")
ui.write_log(f"SYS: Ultron online | Model: {MODEL}")

def handle_text(msg: str):
    ui.set_state("THINKING")
    history.append({"role": "user", "content": msg})
    try:
        r = requests.post(
            f"{BASE}/chat/completions",
            headers={"Authorization": f"Bearer {get_key()}", "Content-Type": "application/json"},
            json={"model": MODEL, "messages": history},
            timeout=30,
        )
        data = r.json()
        if "choices" in data:
            reply = data["choices"].pop(0)["message"]["content"]
            history.append({"role": "assistant", "content": reply})
            ui.set_state("SPEAKING")
            ui.write_log(f"Ultron: {reply}")
        else:
            err = data.get("error", {}).get("message", str(data))
            ui.write_log(f"API ERR: {err}")
    except Exception as e:
        ui.write_log(f"ERR: {e}")
    finally:
        ui.set_state("IDLE")

ui._win.on_text_command = handle_text
ui.root.mainloop()
